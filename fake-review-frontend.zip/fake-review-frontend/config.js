// Frontend configuration. Change this if the backend runs somewhere else.
window.APP_CONFIG = {
  API_BASE_URL: 'http://localhost:8080'
};
