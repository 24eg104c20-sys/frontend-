# Fake Review Detector - Frontend

Static HTML/CSS/JS app. No build step. It talks to the backend only over HTTP.

## Files
index.html | style.css | app.js | config.js

## Configure
Edit `config.js` and set `API_BASE_URL` to where the backend is running
(default `http://localhost:8080`).

## Run
```
python3 -m http.server 3000
```
Open http://localhost:3000 (or just open `index.html` in a browser).

The backend must be running and must allow this origin via CORS (it allows all origins by default).
